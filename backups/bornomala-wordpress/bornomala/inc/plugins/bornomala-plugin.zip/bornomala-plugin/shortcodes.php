<?php

//Promotion Area
function bornomala_promotion_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'sec_content' => 'Welcome to <strong>Bornomala</strong> kindergarten School',                       

		), $atts )
    );
ob_start();

?>

<!-- START PROMOTION -->	
<section class="promotion section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="single_promo">
					<h1><?php echo bornomala_wp_kses($sec_content);?></h1>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END PROMOTION -->		
		
<?php 
  return ob_get_clean();
}
add_shortcode ('promotion_area', 'bornomala_promotion_area' );

//Acitives Area
function bornomala_acitives_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'sec_title' => 'Our Activities',                       
            'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru<br> exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',                       
            'number_of_post' => '6'               

		), $atts )
    );
ob_start();

?>

	<!-- START ACTIVITES  -->
	<section class="our_activites">
		<div class="container">
			<div class="row text-center">
				<div class="section-title wow zoomIn">
					<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
					<span></span>
					<p><?php echo bornomala_wp_kses($sec_subtitle);?></p>
				</div>
				
				<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'activites' ),
					'posts_per_page'         => $number_of_post,
				);

				// The Query
				$bornomala_activites_query = new WP_Query( $args );

				// The Loop
				if ( $bornomala_activites_query->have_posts() ) {
					while ( $bornomala_activites_query->have_posts() ) {
						$bornomala_activites_query->the_post();
						$bornomala_activites_icon = get_post_meta(get_the_ID(), '_bornomala_activites_icon', true);
						$bornomala_activites_bg_color = get_post_meta(get_the_ID(), '_bornomala_activites_bg_color', true);
						
						?>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="single_activites" style="background-color: <?php echo esc_attr($bornomala_activites_bg_color);?>;">
								<i class="<?php echo esc_attr($bornomala_activites_icon);?>"></i>
								<h4><?php the_title();?></h4>
								<p><?php the_content();?></p>
							</div>
						</div><!--END COL -->						
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();

				?>		
				

				
			
			</div><!--END  ROW -->
		</div><!-- END CONTAINER -->
	</section>
	<!-- END ACTIVITES-->			
		
<?php 
  return ob_get_clean();
}
add_shortcode ('acitives_area', 'bornomala_acitives_area' );

//Gallery Area
function bornomala_gallery_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'sec_title' => 'Gallery',                       
            'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru<br> exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',                                  
            'see_more_btn_text' => 'See More prtfolio',                                  
            'see_more_btn_link' => '#',                                  

		), $atts )
    );
ob_start();

?>

<!-- START PORTFOLIO -->
<section id="portfolio" class="template_portfolio section-padding">
	<div class="container">
		<div class="row">
			<div class="section-title text-center wow zoomIn">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>
				<p><?php echo bornomala_wp_kses($sec_subtitle);?></p>
			</div>						
			<?php $terms = get_terms('cat_gallery');
					if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
				?>
				<ul class="portfolio-filters text-center">
					<li class="filter active" data-filter="all"><?php esc_html_e('all' , 'bornomala');?></li>
					<?php foreach ( $terms as $term ) :?>
					<li class="filter" data-filter="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></li>
					
					<?php endforeach;?>
				</ul>
			<?php }?>
				
			<!-- END PORTFOLIO FILTER-->
			<div class="grid">
			
				<?php

				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'gallery' ),
					'posts_per_page'         => -1,
				);

				// The Query
				$bornomala_gallery_query = new WP_Query( $args );

				// The Loop
				if ( $bornomala_gallery_query->have_posts() ) {
					while ( $bornomala_gallery_query->have_posts() ) {
						$bornomala_gallery_query->the_post();
						$bornomalal_gallery_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'bornomala_gallery_img');
						 

							$portfolio_terms = get_the_terms(get_the_id(), 'cat_gallery');
							
							if ( ! empty( $portfolio_terms ) && ! is_wp_error( $portfolio_terms ) ):
								
								$portfolios_cat_slug = array();
								
								foreach($portfolio_terms as $portfolio_term){
									$portfolios_cat_slug[] = $portfolio_term->slug ;
								}
								
								$portfolios_cat_array = join(" ", $portfolios_cat_slug);
								$portfolios_class_array = join(" ", $portfolios_cat_slug);
							endif;
						?>								
								<div class="col-md-4 col-sm-4 mix class <?php echo esc_attr($portfolios_class_array);?>">
									   <div class="image-wrapper">
											<img src="<?php echo esc_url($bornomalal_gallery_image[0]);?>" class="img-responsive" >
									   <div class="image-overlay">
										   <span>
										   <a href="<?php echo esc_url($bornomalal_gallery_image[0]);?>" class="image-popup"><?php the_title();?></a>
										   </span>
										</div>
									  </div>
								</div> <!--work item-->		
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
				?>				
			 </div><!--/.grid-->		
		</div><!--- END ROW -->	
		<div class="portfolio_btn text-center">
			<a href="<?php echo esc_url($see_more_btn_link);?>" class="btn btn-light-bg"><?php echo esc_html($see_more_btn_text);?></a>
		</div>				
	</div><!--- END CONTAINER -->
</section>
<!-- START PORTFOLIO -->
		
		
<?php 
  return ob_get_clean();
}
add_shortcode ('gallery_area', 'bornomala_gallery_area' );

//Counter Area
function bornomala_counter_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'sec_number' => '25',                       
            'sec_text' => 'Teacher & stuff',                                  
                                

		), $atts )
    );
ob_start();

?>

<div class="col-md-3 col-sm-6 col-xs-12 wow fadeInLeft text-center" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
	<div class="counter">
		<div class="single_counter">
			<h2 class="timer"> <?php echo esc_html($sec_number);?></h2> 
		</div> 
		<p><?php echo esc_html($sec_text);?></p>
	 </div>
</div> <!--- END COL -->   
		
		
<?php 
  return ob_get_clean();
}
add_shortcode ('counter_area', 'bornomala_counter_area' );

//Teachers Area
function bornomala_teachers_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'sec_title' => 'Our Teachers',                       
            'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru<br> exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',                                  
            'number_of_post' => '8',                                  
            
		), $atts )
    );
ob_start();

?>

<!-- START TEAM -->
<section id="team" class="template_team">
	<div class="container"> 
		<div class="row text-center"> 
			<div class="section-title wow zoomIn">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>
				<p><?php echo bornomala_wp_kses($sec_subtitle);?></p>
			</div>		
		
			<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'teachers' ),
					'posts_per_page'         => $number_of_post,
				);

				// The Query
				$bornomala_teachers_query = new WP_Query( $args );

				// The Loop
				if ( $bornomala_teachers_query->have_posts() ) {
					while ( $bornomala_teachers_query->have_posts() ) {
						$bornomala_teachers_query->the_post();
						$bornomala_teachers_group_field_opt = get_post_meta(get_the_ID(), '_bornomala_teachers_group_field_opt', true);
						$bornomala_teachers_dagination = get_post_meta(get_the_ID(), '_bornomala_teachers_dagination', true);
						$bornomalal_teachers_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'bornomala_teacher_img');
						
						?>
						
						<div class="col-md-3 col-sm-6">
							<div class="single_team"> 
								<img class="img-responsive" src="<?php echo esc_url($bornomalal_teachers_image[0]);?>" alt="">
								<h5 class="team-name"><?php the_title();?></h5>
								<div class="team-hover">
									<h5><?php the_title();?></h5>
									<span><?php echo esc_html($bornomala_teachers_dagination);?></span>
									<p><?php the_content();?></p>
									
									<ul class="social">
										<?php

											foreach ( (array) $bornomala_teachers_group_field_opt as $key => $pt_entry ) {

												$icon = $link = '';

												if ( isset( $pt_entry['_bornomala_teachers_sm_icon'] ) )
													$icon = $pt_entry['_bornomala_teachers_sm_icon'] ;	

												if ( isset( $pt_entry['_bornomala_teachers_sm_link'] ) )
													$link = $pt_entry['_bornomala_teachers_sm_link'] ;
												
												?>

											<li><a href="<?php echo esc_url($link);?>"><i class="<?php echo esc_attr($icon);?>"></i></a></li>
											
										<?php } ?>	

									</ul>
								</div>
							</div>
						</div><!--- END COL -->	
						
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
			?>		

		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->
</section>
<!-- END TEAM -->
		
		
<?php 
  return ob_get_clean();
}
add_shortcode ('teachers_area', 'bornomala_teachers_area' );

//Events Area
function bornomala_events_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'sec_title' => 'Our Events',                       
            'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',                                                               
            
		), $atts )
    );
ob_start();

?>

<!-- START EVENT -->
<section id="event" class="our_event section-padding">
	<div class="container">
		<div class="row">
			<div class="section-title text-center wow zoomIn">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>
				<p><?php echo bornomala_wp_kses($sec_subtitle);?></p>
			</div>	
			<div class="carousel slide">
				<div class="event-carousel">
				
				<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'events' ),
						'posts_per_page'         => '-1',
					);

					// The Query
					$bornomala_events_query = new WP_Query( $args );

					// The Loop
					if ( $bornomala_events_query->have_posts() ) {
						while ( $bornomala_events_query->have_posts() ) {
							$bornomala_events_query->the_post();
							$bornomalal_events_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'bornomala_gallery_img');
							$bornomala_events_date = get_post_meta(get_the_ID(), '_bornomala_events_date', true);
							?>
							
							<div class="item">
								<div class="col-md-12 col-sm-12 col-xs-12">
									<div class="single_event">
										<img class="event-photo" src="<?php echo esc_url($bornomalal_events_image[0]);?>"/>
										<div class="single_event_text">
											 <span><?php echo esc_html($bornomala_events_date);?></span>
											 <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
											 <p><?php echo bornomala_readmore_content(16);?></p>
										</div>
									</div><!--- END SINGLE EVENT -->
								</div><!--- END COL -->
							</div><!--- END ITEM -->							
							<?php
						}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>				


				</div><!--- END CAROUSEL-INNER -->
			</div><!--- END CAROUSEL SLIDE -->
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END EVENT -->

		
<?php 
  return ob_get_clean();
}
add_shortcode ('events_area', 'bornomala_events_area' );

//Events Two
function bornomala_events_two( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'sec_title' => 'Our Events',                       
            'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',                                                               
            'number_of_post' => '4',                                                               
            
		), $atts )
    );
ob_start();

?>

<!-- START EVENT -->
<section class="our_event our_event_mbtop">
	<div class="container">
		<div class="row">
			<div class="section-title text-center wow zoomIn">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>
				<p><?php echo bornomala_wp_kses($sec_subtitle);?></p>
			</div>	

		<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'events' ),
						'posts_per_page'         => $number_of_post,
					);

					// The Query
					$bornomala_events_query = new WP_Query( $args );

					// The Loop
					if ( $bornomala_events_query->have_posts() ) {
						while ( $bornomala_events_query->have_posts() ) {
							$bornomala_events_query->the_post();							
							$bornomalal_events_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'bornomala_gallery_img');
							$bornomala_events_date = get_post_meta(get_the_ID(), '_bornomala_events_date', true);
							?>
							
								<div class="col-md-6 col-sm-12 col-xs-12">
									<div class="single_event single_event_mb60">
										<img class="event-photo" src="<?php echo esc_url($bornomalal_events_image[0]);?>"/>
										<div class="single_event_text">
											 <span><?php echo esc_html($bornomala_events_date);?></span>
											 <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
											 <p><?php echo bornomala_readmore_content(16);?></p>
										</div>
									</div><!--- END SINGLE EVENT -->
								</div><!--- END COL -->
				
							<?php
						}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>	
				

		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END EVENT -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('events_two', 'bornomala_events_two' );

//Testimonials Area
function bornomala_testimonials_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'sec_bg_img' => '',                                                       
			'sec_title' => 'What Parents say',                                                       
            
		), $atts )
    );
ob_start();
$sec_bg_img = wp_get_attachment_image_src($sec_bg_img,'');
?>

<!-- START TESTIMONIAL -->
<section class="testimonial section-padding" style="background-image: url(<?php echo esc_url($sec_bg_img[0]);?>);  background-size:cover; background-position: center center;">
	<div class="container">
		<div class="row">				
			<div class="col-sm-10 col-sm-offset-1 col-xs-12">
				<h2 class="testimonial_title text-center"><?php echo bornomala_wp_kses($sec_title);?></h2>
				<div id="testimonial__carousel">

					<?php
						// WP_Query arguments
						$args = array(
							'post_type'              => array( 'testimonials' ),
							'posts_per_page'         => -1,
						);

						// The Query
						$bornomala_testimonials_query = new WP_Query( $args );

						// The Loop
						if ( $bornomala_testimonials_query->have_posts() ) {
							while ( $bornomala_testimonials_query->have_posts() ) {
								$bornomala_testimonials_query->the_post();
								
								?>
								<div class="item">
									<div class="testimonial-text text-center">
										<p><?php esc_html_e('"' , 'bornomala'); the_content(); esc_html_e('...."' , 'bornomala');?></p>
										<h4><?php the_title();?></h4>
									</div>
								</div>								
								<?php
							}
						} else {
							// no posts found
						}

						// Restore original Post Data
						wp_reset_postdata();
					?>					

				</div>
			</div><!--- END COL -->				
		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->	
</section>
<!-- END TESTIMONIAL -->

		
<?php 
  return ob_get_clean();
}
add_shortcode ('testimonials_area', 'bornomala_testimonials_area' );

//Class Area
function bornomala_class_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                  
			'sec_title' => 'Our Class',                                                       
			'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',                                                       
			'sec_age_text' => 'Years Old',                                                       
			'number_of_post' => '3',                                                       
            
		), $atts )
    );
ob_start();

?>

		
<!-- START CLASS -->
<section class="our_class section-padding">
	<div class="container">		
		<div class="row">
			<div class="section-title text-center">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>
				<p><?php echo bornomala_wp_kses($sec_subtitle);?></p>
			</div>	
			<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'class' ),
					'posts_per_page'         => $number_of_post,
				);

				// The Query
				$bornomala_class_query = new WP_Query( $args );

				// The Loop
				if ( $bornomala_class_query->have_posts() ) {
					while ( $bornomala_class_query->have_posts() ) {
						$bornomala_class_query->the_post();
						$bornomala_class_age = get_post_meta(get_the_ID(), '_bornomala_class_age', true);
            $bornomalal_class_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'bornomala_gallery_img');
						?>
						
						<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
							<div class="single-blog">
								<div class="single-img">
									<img class="img-responsive" src="<?php echo esc_url($bornomalal_class_image[0]);?>"/>
									<div class="post-date">
										<a href="<?php the_permalink();?>"><h4><strong><?php the_title();?></strong><br> <?php echo esc_html($sec_age_text);?><br><?php echo esc_html($bornomala_class_age);?></h4></a>
									</div>									
								</div>	
							</div>
						</div><!-- END COL -->		
						
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
			?>			
			
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END CLASS -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('class_area', 'bornomala_class_area' );

//Contact info Area
function bornomala_contact_info_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                  
			'sec_bd_color' => '#26547c',                                                       
			'sec_icon' => 'fa fa-phone',                                                                                                            
			'sec_info' => '	<p>(+1) 740-395-3829</p> <p>(+1) 740-395-3829</p>',                                                                                                            
            
		), $atts )
    );
ob_start();

?>

		
<div class="col-md-3 col-sm-6 col-xs-12 text-center">
	<div class="single_address" style="background-color: <?php echo esc_attr($sec_bd_color);?>;">
		<i class="<?php echo esc_attr($sec_icon);?>"></i>
		<?php echo bornomala_wp_kses($sec_info);?>
	</div>
</div><!-- END COL  -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('contact_info_area', 'bornomala_contact_info_area' );

//About Us Area
function bornomala_about_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                  
			'sec_title' => 'About us',                                                                                                                                                               
			'sec_heading' => 'About Bornomala',                                                                                                                                                               
			'sec_content' => '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. </p>
					<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here. </p>',                                                                                                                                                               
          	
			'sec_video_url' => 'https://player.vimeo.com/video/131603349',                                                                                                                                                               
            
		), $atts )
    );
ob_start();

?>

		
<!-- START ABOUT -->
<section id="about" class="about_us section-padding">
	<div class="container">
		<div class="row">
			<div class="section-title text-center">
				<h2><?php echo esc_html($sec_title);?></h2>
				<span></span>
			</div>					
		   <div class="col-md-6 col-sm-12 col-xs-12">
				<div class="about_content">
					<h1><?php echo esc_html($sec_heading);?></h1>
					<?php echo bornomala_wp_kses($sec_content);?>
				</div>
			</div><!--- END COL -->	
		   <div class="col-md-6 col-sm-12 col-xs-12">
				<div class="about-slide">
					<iframe src="<?php echo esc_url($sec_video_url);?>"></iframe>
				</div>
			</div><!--- END COL -->						
		</div><!-- END ROW  -->
	</div><!-- END CONTAINER  -->
</section>	
<!-- END ABOUT -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('about_us_area', 'bornomala_about_us_area' );

//Pricing Area
function bornomala_pricing_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                  
			'sec_title' => 'Pricing Plan',                                                                                                                                                                                                                                                                                                                  
			'number_of_post' => '3',                                                                                                                                                                                                                                                                                                                  
            
		), $atts )
    );
ob_start();

?>

<!-- START PRICING TABLE  -->
<section id="price" class="pricing_table section-padding">
	<div class="container">
		<div class="row text-center">
			<div class="section-title">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>
			</div>

			<?php

				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'pricing' ),
					'posts_per_page'         => $number_of_post,
				);

				// The Query
				$bornomala_pricing_query = new WP_Query( $args );

				// The Loop
				if ( $bornomala_pricing_query->have_posts() ) {
					while ( $bornomala_pricing_query->have_posts() ) {
						$bornomala_pricing_query->the_post();
						$bornomala_pricing_feature = get_post_meta(get_the_ID(), '_bornomala_pricing_feature', true);
						$bornomala_pricing_currency = get_post_meta(get_the_ID(), '_bornomala_pricing_currency', true);
						$bornomala_pricing_amount = get_post_meta(get_the_ID(), '_bornomala_pricing_amount', true);
						$bornomala_pricing_period = get_post_meta(get_the_ID(), '_bornomala_pricing_period', true);
						$bornomala_pricing_group_field_opt = get_post_meta(get_the_ID(), '_bornomala_pricing_group_field_opt', true);
						$bornomala_pricing_btn_text = get_post_meta(get_the_ID(), '_bornomala_pricing_btn_text', true);
						$bornomala_pricing_btn_link = get_post_meta(get_the_ID(), '_bornomala_pricing_btn_link', true);
												
						?>
						
						<div class="col-sm-4 col-md-4">				   
						   <div class="plan  first">
							  <div class="head <?php if($bornomala_pricing_feature == true){ echo esc_attr('head_color_two'); }else{ echo esc_attr('head_color_one'); } ?>"><h3><?php the_title();?></h3></div> 
							  <div class="price">
								<h3><span class="symbol"><?php echo esc_html($bornomala_pricing_currency);?></span><?php echo esc_html($bornomala_pricing_amount);?></h3>
								<h4><?php echo esc_html($bornomala_pricing_period);?></h4>
							  </div>						  
							  <ul class="item-list">
							<?php
								
									foreach ( (array) $bornomala_pricing_group_field_opt as $key => $pricing_entry ) {

										$feature =  '';

										if ( isset( $pricing_entry['_bornomala_single_feature'] ) )
											$feature = $pricing_entry['_bornomala_single_feature'];

										?>
										
											<li><?php echo esc_html($feature);?></li>
																			
									<?php 
									
									} ?>
									
							  </ul>
							 <a class="btn btn-light-bg" href="<?php echo esc_url($bornomala_pricing_btn_link);?>"><?php echo esc_html($bornomala_pricing_btn_text);?></a>
						   </div>					 					
						</div><!--- END COL --> 
 						
						<?php
						// do something
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
			?>			
			
			
		</div><!--END  ROW  -->
	</div><!-- END CONTAINER  -->
</section>
<!-- END PRICING TABLE  -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('pricing_area', 'bornomala_pricing_area' );

//Google Map
function bornomala_google_map_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
               'sec_lati' => '40.7127837' ,                                                               
               'sec_longi' => '-74.00594130000002' ,                                                               
               'sec_api_key' => 'AIzaSyDwIQh7LGryQdDDi-A603lR8NqiF3R_ycA' ,                                                               

		), $atts )
    );
ob_start(); ?>

<!-- START MAP -->
<div id="map"></div>	
<!-- END MAP -->

<!-- map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_js($sec_api_key);?>"></script>	
	
<script>

jQuery(document).on('ready', function(){
	
	/*START CONTACT MAP JS*/
		function initialize() {
		  var mapOptions = {
			zoom: 15,
			scrollwheel: false,
			center: new google.maps.LatLng(<?php echo esc_js($sec_lati);?>, <?php echo esc_js($sec_longi);?>)
		  };
		  var map = new google.maps.Map(document.getElementById('map'),
			  mapOptions);
		  var marker = new google.maps.Marker({
			position: map.getCenter(),
			icon: '<?php echo esc_url(get_template_directory_uri());?>/assets/img/map_pin.png',
			map: map
			
		  });
		}
		google.maps.event.addDomListener(window, 'load', initialize);	
	   /*END CONTACT MAP JS*/
	});    
</script>

<?php
  return ob_get_clean();
}
add_shortcode ('google_map_area', 'bornomala_google_map_area' );

//Contact Us
function bornomala_contact_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
               'sec_title' => 'get in touch' ,                                                                                                                           
               'sec_shortcode' => '' ,                                                                                                                           

		), $atts )
    );
ob_start(); ?>

<!-- START CONTACT FORM AND MAP -->
<section class="footer_contact_area section-padding">
	<div class="container-fluid">
		<div class="row">	
			<div class="section-title text-center wow zoomIn">
				<h2><?php echo bornomala_wp_kses($sec_title);?></h2>
				<span></span>						
			</div>			
			
			<div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
				<div class="footer_contact">
					<div id="contact-form">
						<div class="row">
							<?php echo do_shortcode($sec_shortcode);?>
						</div>
					</div>
				</div>
			</div><!-- END COL -->						
		</div><!--- END ROW -->				
	</div><!--- END CONTAINER -->	
</section>
<!-- END CONTACT FORM  AND MAP -->

<?php
  return ob_get_clean();
}
add_shortcode ('contact_us_area', 'bornomala_contact_us_area' );

//Shortcode Importer
function bornomala_shortcode_importer( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                   
            'enter_shortcode' => '',                                                                              

		), $atts )
    );

	echo do_shortcode($enter_shortcode);
}
add_shortcode ('shortcode_importer', 'bornomala_shortcode_importer' );
