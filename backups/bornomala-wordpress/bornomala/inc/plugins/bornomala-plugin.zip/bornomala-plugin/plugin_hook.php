<?php

/*

Plugin Name: Bornomala Plugin

Plugin URI: http://getmasum.net

Description: After install the Bornomala WordPress Theme, you must need to install this "Bornomala Plugin" first to get all functions of Bornomala WP Theme.

Author: Masum Billah

Author URI: http://www.getmasum.net

Version: 1.0

Text Domain: bornomala

*/


//define

define( 'BORNOMALAPLUGINDIR', dirname( __FILE__ ) ); 

// Add main files

include_once(BORNOMALAPLUGINDIR. '/custom_posts.php');
include_once(BORNOMALAPLUGINDIR. '/shortcodes.php');