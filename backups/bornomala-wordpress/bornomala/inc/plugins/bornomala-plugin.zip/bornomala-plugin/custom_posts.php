<?php

if ( ! function_exists('bornomala_activities_area') ) {

// Register Custom Post Type
function bornomala_activities_area() {

	$labels = array(
		'name'                  => esc_html_x( 'Activites', 'Post Type General Name', 'bornomala' ),
		'singular_name'         => esc_html_x( 'Activite', 'Post Type Singular Name', 'bornomala' ),
		'menu_name'             => esc_html__( 'Activites', 'bornomala' ),
		'name_admin_bar'        => esc_html__( 'Activites', 'bornomala' ),
		'archives'              => esc_html__( 'Item Archives', 'bornomala' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bornomala' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bornomala' ),
		'all_items'             => esc_html__( 'All Items', 'bornomala' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bornomala' ),
		'add_new'               => esc_html__( 'Add New', 'bornomala' ),
		'new_item'              => esc_html__( 'New Item', 'bornomala' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'           => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'             => esc_html__( 'View Item', 'bornomala' ),
		'view_items'            => esc_html__( 'View Items', 'bornomala' ),
		'search_items'          => esc_html__( 'Search Item', 'bornomala' ),
		'not_found'             => esc_html__( 'Not found', 'bornomala' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bornomala' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bornomala' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bornomala' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bornomala' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bornomala' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bornomala' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bornomala' ),
		'items_list'            => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bornomala' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bornomala' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Activite', 'bornomala' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-lightbulb',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'activites', $args );

}
add_action( 'init', 'bornomala_activities_area', 0 );

}

// Register Custom Post Type
function bornomala_galleries() {

	$labels = array(
		'name'                  => esc_html_x( 'Galleries', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => esc_html_x( 'Gallery', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => esc_html__( 'Gallery', 'text_domain' ),
		'name_admin_bar'        => esc_html__( 'Gallery', 'text_domain' ),
		'archives'              => esc_html__( 'Item Archives', 'text_domain' ),
		'attributes'            => esc_html__( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'text_domain' ),
		'all_items'             => esc_html__( 'All Items', 'text_domain' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'text_domain' ),
		'add_new'               => esc_html__( 'Add New', 'text_domain' ),
		'new_item'              => esc_html__( 'New Item', 'text_domain' ),
		'edit_item'             => esc_html__( 'Edit Item', 'text_domain' ),
		'update_item'           => esc_html__( 'Update Item', 'text_domain' ),
		'view_item'             => esc_html__( 'View Item', 'text_domain' ),
		'view_items'            => esc_html__( 'View Items', 'text_domain' ),
		'search_items'          => esc_html__( 'Search Item', 'text_domain' ),
		'not_found'             => esc_html__( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => esc_html__( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => esc_html__( 'Items list', 'text_domain' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Gallery', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-video-alt2',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'gallery', $args );

}
add_action( 'init', 'bornomala_galleries', 0 );

if ( ! function_exists( 'bornomala_gallery_category' ) ) {

// Register Custom Taxonomy
function bornomala_gallery_category() {

	$labels = array(
		'name'                       => esc_html_x( 'Categories', 'Taxonomy General Name', 'bornomala' ),
		'singular_name'              => esc_html_x( 'Category', 'Taxonomy Singular Name', 'bornomala' ),
		'menu_name'                  => esc_html__( 'Gallery', 'bornomala' ),
		'all_items'                  => esc_html__( 'All Items', 'bornomala' ),
		'parent_item'                => esc_html__( 'Parent Item', 'bornomala' ),
		'parent_item_colon'          => esc_html__( 'Parent Item:', 'bornomala' ),
		'new_item_name'              => esc_html__( 'New Item Name', 'bornomala' ),
		'add_new_item'               => esc_html__( 'Add New Item', 'bornomala' ),
		'edit_item'                  => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'                => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'                  => esc_html__( 'View Item', 'bornomala' ),
		'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'bornomala' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove items', 'bornomala' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'bornomala' ),
		'popular_items'              => esc_html__( 'Popular Items', 'bornomala' ),
		'search_items'               => esc_html__( 'Search Items', 'bornomala' ),
		'not_found'                  => esc_html__( 'Not Found', 'bornomala' ),
		'no_terms'                   => esc_html__( 'No items', 'bornomala' ),
		'items_list'                 => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation'      => esc_html__( 'Items list navigation', 'bornomala' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'cat_gallery', array( 'gallery' ), $args );

}
add_action( 'init', 'bornomala_gallery_category', 0 );

}

if ( ! function_exists('bornomala_teachers') ) {

// Register Custom Post Type
function bornomala_teachers() {

	$labels = array(
		'name'                  => esc_html_x( 'Teachers', 'Post Type General Name', 'bornomala' ),
		'singular_name'         => esc_html_x( 'Teacher', 'Post Type Singular Name', 'bornomala' ),
		'menu_name'             => esc_html__( 'Teachers', 'bornomala' ),
		'name_admin_bar'        => esc_html__( 'Post Type', 'bornomala' ),
		'archives'              => esc_html__( 'Item Archives', 'bornomala' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bornomala' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bornomala' ),
		'all_items'             => esc_html__( 'All Items', 'bornomala' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bornomala' ),
		'add_new'               => esc_html__( 'Add New', 'bornomala' ),
		'new_item'              => esc_html__( 'New Item', 'bornomala' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'           => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'             => esc_html__( 'View Item', 'bornomala' ),
		'view_items'            => esc_html__( 'View Items', 'bornomala' ),
		'search_items'          => esc_html__( 'Search Item', 'bornomala' ),
		'not_found'             => esc_html__( 'Not found', 'bornomala' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bornomala' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bornomala' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bornomala' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bornomala' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bornomala' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bornomala' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bornomala' ),
		'items_list'            => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bornomala' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bornomala' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Teacher', 'bornomala' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-welcome-learn-more',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'teachers', $args );

}
add_action( 'init', 'bornomala_teachers', 0 );

}

if ( ! function_exists('bornomala_events') ) {

// Register Custom Post Type
function bornomala_events() {

	$labels = array(
		'name'                  => esc_html_x( 'Events', 'Post Type General Name', 'bornomala' ),
		'singular_name'         => esc_html_x( 'Event', 'Post Type Singular Name', 'bornomala' ),
		'menu_name'             => esc_html__( 'Events', 'bornomala' ),
		'name_admin_bar'        => esc_html__( 'Events', 'bornomala' ),
		'archives'              => esc_html__( 'Item Archives', 'bornomala' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bornomala' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bornomala' ),
		'all_items'             => esc_html__( 'All Items', 'bornomala' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bornomala' ),
		'add_new'               => esc_html__( 'Add New', 'bornomala' ),
		'new_item'              => esc_html__( 'New Item', 'bornomala' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'           => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'             => esc_html__( 'View Item', 'bornomala' ),
		'view_items'            => esc_html__( 'View Items', 'bornomala' ),
		'search_items'          => esc_html__( 'Search Item', 'bornomala' ),
		'not_found'             => esc_html__( 'Not found', 'bornomala' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bornomala' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bornomala' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bornomala' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bornomala' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bornomala' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bornomala' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bornomala' ),
		'items_list'            => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bornomala' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bornomala' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Event', 'bornomala' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-calendar-alt',		
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'events', $args );

}
add_action( 'init', 'bornomala_events', 0 );

}


if ( ! function_exists('bornomala_testimonials') ) {

// Register Custom Post Type
function bornomala_testimonials() {

	$labels = array(
		'name'                  => esc_html_x( 'Testimonials', 'Post Type General Name', 'bornomala' ),
		'singular_name'         => esc_html_x( 'Testimonials', 'Post Type Singular Name', 'bornomala' ),
		'menu_name'             => esc_html__( 'Testimonials', 'bornomala' ),
		'name_admin_bar'        => esc_html__( 'Testimonials', 'bornomala' ),
		'archives'              => esc_html__( 'Item Archives', 'bornomala' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bornomala' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bornomala' ),
		'all_items'             => esc_html__( 'All Items', 'bornomala' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bornomala' ),
		'add_new'               => esc_html__( 'Add New', 'bornomala' ),
		'new_item'              => esc_html__( 'New Item', 'bornomala' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'           => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'             => esc_html__( 'View Item', 'bornomala' ),
		'view_items'            => esc_html__( 'View Items', 'bornomala' ),
		'search_items'          => esc_html__( 'Search Item', 'bornomala' ),
		'not_found'             => esc_html__( 'Not found', 'bornomala' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bornomala' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bornomala' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bornomala' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bornomala' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bornomala' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bornomala' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bornomala' ),
		'items_list'            => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bornomala' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bornomala' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Testimonials', 'bornomala' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-format-quote',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonials', $args );

}
add_action( 'init', 'bornomala_testimonials', 0 );

}

if ( ! function_exists('bornomala_class') ) {

// Register Custom Post Type
function bornomala_class() {

	$labels = array(
		'name'                  => esc_html_x( 'Class', 'Post Type General Name', 'bornomala' ),
		'singular_name'         => esc_html_x( 'Class', 'Post Type Singular Name', 'bornomala' ),
		'menu_name'             => esc_html__( 'Class', 'bornomala' ),
		'name_admin_bar'        => esc_html__( 'Class', 'bornomala' ),
		'archives'              => esc_html__( 'Item Archives', 'bornomala' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bornomala' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bornomala' ),
		'all_items'             => esc_html__( 'All Items', 'bornomala' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bornomala' ),
		'add_new'               => esc_html__( 'Add New', 'bornomala' ),
		'new_item'              => esc_html__( 'New Item', 'bornomala' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'           => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'             => esc_html__( 'View Item', 'bornomala' ),
		'view_items'            => esc_html__( 'View Items', 'bornomala' ),
		'search_items'          => esc_html__( 'Search Item', 'bornomala' ),
		'not_found'             => esc_html__( 'Not found', 'bornomala' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bornomala' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bornomala' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bornomala' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bornomala' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bornomala' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bornomala' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bornomala' ),
		'items_list'            => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bornomala' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bornomala' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Class', 'bornomala' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-sos',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'class', $args );

}
add_action( 'init', 'bornomala_class', 0 );

}

if ( ! function_exists('bornomala_pricing') ) {

// Register Custom Post Type
function bornomala_pricing() {

	$labels = array(
		'name'                  => esc_html_x( 'Pricing', 'Post Type General Name', 'bornomala' ),
		'singular_name'         => esc_html_x( 'Pricing', 'Post Type Singular Name', 'bornomala' ),
		'menu_name'             => esc_html__( 'Pricing', 'bornomala' ),
		'name_admin_bar'        => esc_html__( 'Pricing', 'bornomala' ),
		'archives'              => esc_html__( 'Item Archives', 'bornomala' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bornomala' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bornomala' ),
		'all_items'             => esc_html__( 'All Items', 'bornomala' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bornomala' ),
		'add_new'               => esc_html__( 'Add New', 'bornomala' ),
		'new_item'              => esc_html__( 'New Item', 'bornomala' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bornomala' ),
		'update_item'           => esc_html__( 'Update Item', 'bornomala' ),
		'view_item'             => esc_html__( 'View Item', 'bornomala' ),
		'view_items'            => esc_html__( 'View Items', 'bornomala' ),
		'search_items'          => esc_html__( 'Search Item', 'bornomala' ),
		'not_found'             => esc_html__( 'Not found', 'bornomala' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bornomala' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bornomala' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bornomala' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bornomala' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bornomala' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bornomala' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bornomala' ),
		'items_list'            => esc_html__( 'Items list', 'bornomala' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bornomala' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bornomala' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Pricing', 'bornomala' ),
		'labels'                => $labels,
		'supports'              => array( 'title', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-list-view',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'pricing', $args );

}
add_action( 'init', 'bornomala_pricing', 0 );

}